function getPatternRLE() {
   var RLEHead = "#CXRLE Pos=-64,-64\nx = 128, y = 128, rule = B3/S23\n", currlen = 0, Pstate, prev, str = ["b","o",""], row = 0, z, z2 = "";
   for (var y = 0; y < 128; ++y) {
      z = "";
      Pstate = 2;
      for (var x = 0; x < 128; ++x) {
          prev = Pstate;
          Pstate = +!!array[x][y];
          var cur1 = currlen === 0 ? "" : (currlen + 1);
          prev === Pstate ? currlen++ : prev === 2 ? 0 : (z += cur1 + str[prev], currlen = 0);
      }
      cur1 = currlen === 0 ? "" : (currlen + 1);
      Pstate && (z += cur1 + str[Pstate]);
      var row1 = row === 0 ? "" : row === 1 ? "$" : row + "$";
      currlen === 127 && cur1 ? row++ : (z = row1 + z, z2 += z, row = 1);
      currlen = 0;
   }
   z2 += "!"
   return RLEHead + RLELineBreak(z2);
}
function RLELineBreak (s) {
   var array = [], n = 0;
   for(var i = 0; i < s.length;) {
      var backupI = i;
      i += 70;
      while (/\d/.test(s[i - 1]) || s[i] === "!") {
        --i;
      }
      array[n++] = s.substring(backupI, i);
   }
   return array.join("\n");
}
function pasteCode (e) {
	for (var x = 0; x < 128; ++x) {
		for (var y = 0; y < 128; ++y) {
			array[x][y] = 0;
		}
	}
	var lines = e.value.split("\n"), x = 0, y = 0, alignX = 0, alignY = 0;
	ctx.clearRect(0, 0, 640, 640);
	for (var i = 0; i < lines.length; ++i) {
		if (lines[i].charAt(0) === "x" && (lines[i].charAt(1) === " " || lines[i].charAt(1) === "=")) {
			var patternX = +lines[i].match(/\bx = (\d+)/)[1].toLowerCase();
			var patternY = +lines[i].match(/\by = (\d+)/)[1].toLowerCase();
			alignX = (128 - patternX) >> 1;
			alignY = (128 - patternY) >> 1;
			var rule = ((lines[i].match(/\brule = ([^:\s]+)(?:\:\S+)?(?:,|$)/)[1].toLowerCase() === "lifehistory") ? 1 : 0);
		} else if (lines[i].charAt(0) !== "#") {
			for (var line = lines[i]; line.length > 0;) {
				var part = line.match(/\d*\D/)[0];
				var last = part.slice(-1);
				var num = +part.slice(0,-1);
				num || (num = 1);
				if (last === "$") {
					y += num; x = 0;
				} else if (last === "o" || rule && /[ACE]/.test(last)) {
					while(num--) {
						array[alignX + x][alignY + y] = Math.floor(Math.random()*255+1);
						ctx.fillStyle = palette[array[alignX + x][alignY + y]];
						ctx.fillRect((alignX + x) * 5, (alignY + y) * 5, 5, 5);
						x++
						// console.log(last)
					}
				} else if (last === "b" || rule && /[\.BDF]/.test(last)) {
					x += num;
				} else {
					return;
				}
				line = line.slice(part.length);
			}
		}
	}
}
function randomFill (d) {
	for (var x = 0; x < 128; ++x) {
		for (var y = 0; y < 128; ++y) {
			array[x][y] = Math.random() < d ? Math.floor(Math.random()*255+1) : 0;
			ctx.fillStyle = palette[array[x][y]];
			ctx.fillRect(x * 5, y * 5, 5, 5);
		}
	}
}